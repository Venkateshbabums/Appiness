$(document).ready(function(){


$('.hospital-accord-blk .card-header .card-link').click(function(){
	$('.hospital-accord-blk .card-header .card-link').removeClass("open");
    if( $(this).parent().next().is(':hidden') ) { //If immediate next container is closed...
        $(this).addClass("open");
    }
    else{
        $(this).removeClass("open");
    }
});

$('.testimonial-block').slick({
  centerMode: false,
  centerPadding: '80px',
  slidesToShow: 2,
  centerMode: true,
  autoplay:true,
   responsive: [
    {
      breakpoint: 992,
      settings: {
   centerPadding: '40px',
      }
    },
    {
      breakpoint: 600,
      settings: {
		  slidesToShow: 1,
		  centerPadding: '40px'
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
		  centerPadding: '40px'
      }
    }
  ]
});

var $gototop = $('.go-to-top');
	$(document).scroll(function() {
		if($(this).scrollTop()> 400)
		{   //alert("scop");
 //  $logo.css({display: $(this).scrollTop() > 100? "block":"none"});
 $('.go-to-top').css("display", "block");
		}else{
 $('.go-to-top').css("display", "none");
		}
	});
	
 $(".go-to-top a").click(function() {
	 event.preventDefault();
        $('html, body').animate({
            scrollTop: $(".header-section").offset().top
        }, 2000);
    });






});